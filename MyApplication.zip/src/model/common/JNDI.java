package model.common;

public class JNDI {

}
