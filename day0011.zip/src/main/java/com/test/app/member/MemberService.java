package com.test.app.member;

public interface MemberService {
	public MemberVO selectOne(MemberVO vo);
		// ex) 로그인 기능
}
