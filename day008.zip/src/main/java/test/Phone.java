package test;

public interface Phone {
	void volumeUp();
	void volumeDown();
	void msg();
}
