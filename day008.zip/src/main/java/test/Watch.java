package test;

public interface Watch {
	public void volumeUp();
	public void volumeDown();
}
